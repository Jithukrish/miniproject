from flask import *

from src.dbconnection import *
from datetime import datetime
app=Flask(__name__)


@app.route('/')
def log():
    return render_template("login.html")

#login function
@app.route('/login', methods=['post'])
def login():
    username=request.form['username']
    password=request.form['password']
    qry=" SELECT * FROM login WHERE u_name=%s and password=%s"
    val=(username,password)
    res=selectone(qry,val)
    if res is None:
        return '''<script>alert("invalid");window.location="login_index"</script>'''
    elif res['user type'] == "admin":
        return '''<script>alert("valid");window.location="admin"</script>'''
    elif res['user type'] == "user":
         return '''<script>alert("valid");window.location="userhome"</script>'''
    elif res['user type'] == "trainer":
         return '''<script>alert("valid");window.location="trainerhome"</script>'''


    else:
        return '''<scrpit>alert("invalid");window.location="login"</scrpit>'''
@app.route('/admin')
def admin():
    return render_template("admin home.html")
@app.route('/admin')
def admin():
    return render_template("admin home.html")
@app.route('/admin')
def admin():
    return render_template("admin home.html")
@app.route('/userhome')
def user():
    return render_template("user home.html")
@app.route('/trainerhome')
def trainer():
    return render_template("trainerhome.html")

#registration
@app.route('/registration', methods=['post'])
def registration():
    User = request.form['textfield']
    Place = request.form['textfield3']
    Gender = request.form['radiobutton']
    Email = request.form['textfield3']
    DOB = request.form['textfield5']
    Phoneno = request.form['textfield4']
    u_name = request.form['textfield6']
    password = request.form['textfield7']
    qry = "INSERT INTO `login` VALUES(NULL,%s,%s,'user')"
    val = (u_name, password)
    id = iud(qry, val)
    qry1 = "INSERT INTO registration VALUES(NULL,%s,%s,%s,%s,%s,%s,%s)"
    val1 = (str(id), User, Place, Gender,DOB,Email,Phoneno)
    iud(qry1, val1)
    return '''<script>alert("Registerd successfuly");window.location="/"</script>'''

@app.route("/userhome")
def userhome():
  return render_template("user home.html")
@app.route("/register")
def register():
    return render_template("registration.html")


app.run(debug=True)
